import Point from './point.js';

export default class Circles {
    constructor(args = {}) {
        this.total_points = args.total_points || 10;
        this.palette = args.palette || ['#A1A2A6', '#024959', '#F2C12E', '#F2AE30', '#593E25'];
        this.bg = this.palette[Math.floor(Math.random() * this.palette.length)];
        this.circles = [];
        for (let i = 1; i <= this.total_points; i++) {
            const randomColor = this.palette[Math.floor(Math.random() * this.palette.length)];
            const point = new Point({
                stroke: 0,
                fill: randomColor,
                size: 300 - (20 * i),
                friction: i * 0.1,
                alpha: 200
            })
            this.circles.push(point);
            console.log(this.palette, this.bg, this.circles);
        }
    }

    draw() {
        background(this.bg);
        for (let i = 0; i < this.circles.length; i++) {
            // blendMode(DARKEST);
            this.circles[i].draw();
        }
    }
}